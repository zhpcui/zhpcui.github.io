
              Demo code for global linear method for camera pose registration
           --------------------------------------------------------------------- 
         Zhaopeng Cui (zhpcui@gmail.com) and Nianjuan Jiang (Nianjuan.jiang@adsc.com.sg)
                                  Version 0.1, November, 2013


This directory contains a compiled binary program under Windows for our core part 
of the global linear method for camera pose registration.

Please see the web page at

for references to the relevant papers describing this approach.

--------------------------
System requirement
--------------------------
The binary program is complied under Visual Studio 2010 using x64 complier. 
Please make sure that the following packages are installed, 
1. Microsoft Visual C++ 2010 Redistributable Package (x64)
 http://www.microsoft.com/en-us/download/details.aspx?id=14632
2. Microsoft Visual C++ 2010 SP1 Redistributable Package (x64)
http://www.microsoft.com/en-us/download/details.aspx?id=13523


--------------------------
The parameters in the configuration file “config.txt” 
--------------------------
1. "ImageList" -- A list of names of images. The format needed is as follows,
<Image0's name>
<Image1's name>
<Image2's name>
	   .
	   .
	   .

	   
2. "CalibrationFile" -- The input file that records the calibration information
for each image. The format needed is as follows,
<f0> <cx0> <cy0> <Image0's Width> <Image0's Height> 
<f1> <cx1> <cy1> <Image1's Width> <Image1's Height> 
<f2> <cx2> <cy2> <Image2's Width> <Image2's Height> 
 .	   .     .          .             .
 .	   .     .          .             .
 

3. "EGsFile" -- The input file that records the epipolar geometry information. 
The format needed is as follows,
p <Number of matches> <ImageN's index> <ImageM's index>
<Relative rotation matrix R 3*3>
<Relative translation vector t 1*3>
<Feature index in ImageN> <x0> <y0> <Feature index in ImageM> <x1> <y1>
.....
(Note: the image index is from zero, and it corresponds to the order of images in ImageList.)
What's more, the relationship here is [x1 y1 1] * inv(K_M)' * E * inv(K_N) * [x0 y0 1]' = 0,
where K_N and K_M are the intrinsic matrices of ImageN and ImageM respectively,
E =(antisymmetric matrix of t)* R.)

4. "TripletListFile" -- The input file that records a list for possible combinations of three views.
If no tripletlist file is inputted, the program will find possible triplets.

5. "delta1" -- The threshold delta1 described in our paper. 

6. "delta2" -- The threshold delta2 described in our paper.			 


In the folder, examples of EGsFile and CalibrationFile have been given. 


--------------------------
Output description
--------------------------
The output of the program is the global rotation matrices and translation vectors of cameras. 
Here the poses for the cameras in the largest connected triplet graph are computed,and the 
poses for other cameras are given as zeros. The output file is called "GlobalSolutions.txt".
Its format is as follows,
<Global rotation matrix R0>
<Global translation vector T0>
<Global rotation matrix R1>
<Global translation vector T1>
<Global rotation matrix R2>
<Global translation vector T2>
              .
              .
              .
			  
			  
			  
--------------------------
Example
--------------------------
You can run with the commands as follows
"LinearSFM.exe config.txt"
